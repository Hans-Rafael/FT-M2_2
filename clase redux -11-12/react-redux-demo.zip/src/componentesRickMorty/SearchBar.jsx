import {useState} from 'react'
import { connect } from 'react-redux'
import { getCharacterByName } from '../store/actions'


function SearchBar(props) {
    const [search, setSearch] = useState('')

    function onInputChange(name) {
        setSearch(name)
    }
    function buscarPorNombre(name) {
        props.getCharacterByName(name)
    }
    return <div>
        <input type="text" value={search} onChange={(e) => onInputChange(e.target.value)} />
        <button onClick={() => buscarPorNombre(search)}>Buscar!</button>
    </div>
}
let conexion = connect(null, {getCharacterByName})
export default conexion(SearchBar)