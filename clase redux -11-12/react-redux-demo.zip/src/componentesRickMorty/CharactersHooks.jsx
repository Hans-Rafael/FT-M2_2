import { useEffect } from "react"
import { useDispatch, useSelector } from "react-redux"
import { getCharacters } from "../store/actions"
import Character from "./Character"

export default function CharactersHooks() {
    const characters = useSelector((state) => state.characters)
    const dispatch = useDispatch()
    useEffect(() => {
        dispatch(getCharacters())
    }, [])
    return <>
        {characters.map((character) => {
            return <Character 
                name={character.name}
                image={character.image}
                species={character.species}
                status={character.status}
            />
        })}
    </>
}