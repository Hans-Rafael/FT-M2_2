import React from 'react'
import { connect } from 'react-redux'
import { getCharacters } from '../store/actions'
import Character from './Character'

class Characters extends React.Component {
    componentDidMount() {
        this.props.getCharacters()
    }
    render() {
        return <>
        {this.props.characters.map((character) => {
            return <Character 
                name={character.name}
                image={character.image}
                species={character.species}
                status={character.status}
            />})}
        </>
    }
}

function mapStateToProps(state) {
    return {
        characters: state.characters //cambie de posicion de memoria, va a volver a renderizar
    }
}

export default connect(mapStateToProps, {getCharacters})(Characters)