import { connect } from "react-redux"
import { orderCharacters } from '../store/actions'
function Order(props) {

    function onInputChange(e) {
        props.orderCharacters(e.target.value)
    }

    return <select name="" id="" onChange={onInputChange}>
        <option value="ascendente">Ascendente</option>
        <option value="descendente">Descendente</option>
    </select>
}

export default connect(null, {orderCharacters})(Order)