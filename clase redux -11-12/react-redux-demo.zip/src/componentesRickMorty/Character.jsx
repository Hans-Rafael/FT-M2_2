export default function Character(props) {
    return <div>
        <img src={props.image} />
        <h3>
            Nombre: {props.name}
        </h3>
        <p>Especie: {props.species}</p>
        <p>Status: {props.status}</p>
        <hr/>
    </div>
}