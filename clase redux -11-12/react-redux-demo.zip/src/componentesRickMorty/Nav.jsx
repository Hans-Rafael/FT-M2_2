import Order from "./Order"
import SearchBar from "./SearchBar"

function Nav() {
    
    return <nav>
        <Order />
        <SearchBar />
    </nav>
}

export default Nav