export default function Operator(props) {
    return <button onClick={props.calc}>
        {props.operator}
    </button>
}