import React from 'react'
import { connect } from 'react-redux'
import {increment, decrement} from '../store/actions'
import Counter from './Counter'
import Operator from './Operator'

class CounterContainer extends React.Component {
    restar = () => {
        this.props.decrement()
    }
    sumar = () => {
        this.props.increment()
    }
    render() {
        return <div>
            <Operator operator="-" calc={this.restar}/>
            {/* <button onClick={this.restar}>-</button> */}
            <Counter count={this.props.count}/>  
            {/* <button onClick={this.sumar}>+</button> */}
            <Operator operator="+" calc={this.sumar}/>
        </div>
    }
}
//connect espera dos parametros, mapStateToProps, mapDispatchToProps
//primer paramatro, el mapStateToProps. Es una funcion que tiene como parametro el estado
// retornar la parte del estado que queremos obtener del store
//el segundo parametro, va a ser un objeto con TODAS las accions que queramos usar
//en nuestro componente
//lo que va a hacer el connect, es pasarnos a las props esas accions y esa parte del estado
//que nosotros queramos usar

function mapStateToProps(state) { //me va a traer una parte del estado
    //el primer parametro es el estado completo
    //retorno la parte del estado que yo quiero llevarme
    return {
        count: state.count,
    }
}

const mapDispatchToProps = {
    increment,
    decrement
}

const conexion = connect(mapStateToProps, mapDispatchToProps)

export default conexion(CounterContainer)