export default function Counter(props) {
    return <span>
        {props.count}
    </span>
}