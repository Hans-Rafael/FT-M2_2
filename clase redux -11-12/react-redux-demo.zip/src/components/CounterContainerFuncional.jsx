import React from 'react'
import { connect } from 'react-redux'
import {increment, decrement} from '../store/actions'
import Counter from './Counter'
import Operator from './Operator'

function CounterContainerFuncional(props) {
    function restar() {
        props.decrement()
    }
    function sumar() {
        props.increment()
    }
    return <div>
        <Operator operator="-" calc={restar}/>
        <Counter count={props.count}/>
        <Operator operator="+" calc={sumar}/>
    </div>
}

function mapStateToProps(state) {
    return {
        count: state.count
    }
}

const conexion = connect(mapStateToProps, { increment, decrement } )

export default conexion(CounterContainerFuncional)