import logo from './logo.svg';
import './App.css';
import CounterContainer from './components/CounterContainer';
import CounterContainerFuncional from './components/CounterContainerFuncional';
import Characters from './componentesRickMorty/Characters';

import Nav from './componentesRickMorty/Nav';
import CharactersHooks from './componentesRickMorty/CharactersHooks';

function App() {
  return (
    <div className="App">
      <Nav />
      <Characters />
      {/* <CounterContainer />
      <CounterContainerFuncional /> */}
    </div>
  );
}

export default App;
