import { DECREMENTAR, GET_CHARACTERS, GET_CHARACTERS_BY_NAME, INCREMENTAR, ORDER } from "../actions";

const initialState = {
    count: 0,
    characters: []
}

export default function reducer(state = initialState, action) {
    switch(action.type) {
        case INCREMENTAR:
            return {
                ...state,
                count: state.count + 1
            }
        case DECREMENTAR:
            return {
                ...state,
                count: state.count - 1
            }
        case GET_CHARACTERS:
            return {
                ...state,
                characters: [...action.payload]
            }
        case GET_CHARACTERS_BY_NAME:
            return {
                ...state,
                characters: [...action.payload]
            }
        case ORDER:
            let characterCopy = [...state.characters]
            let sortArray
            if(action.payload === "ascendente") {
                sortArray = characterCopy.sort((a, b) => {
                    if(a.name < b.name) return -1
                    if(a.name > b.name) return +1
                    return 0
                })
            } else {
                sortArray = characterCopy.sort((a, b) => {
                    if(a.name > b.name) return -1
                    if(a.name < b.name) return +1
                    return 0
                })
            }
            return {
                ...state,
                characters: sortArray
            }
        default:
            return state
    }
}