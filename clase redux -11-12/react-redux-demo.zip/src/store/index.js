import {applyMiddleware, createStore} from 'redux'
import reducer from './reducer'
import thunk from 'redux-thunk'
/*
    nos permite es utilizar funciones asincronicas en nuestras acciones
*/
const store = createStore(reducer, applyMiddleware(thunk))

export default store;