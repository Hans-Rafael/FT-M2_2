export const INCREMENTAR = 'INCREMENTAR'
export const DECREMENTAR = 'DECREMENTAR'
export const GET_CHARACTERS = 'GET_CHARACTERS'
export const GET_CHARACTERS_BY_NAME = 'GET_CHARACTERS_BY_NAME'
export const ORDER = 'ORDER'

export function orderCharacters(order) {
    return {
        type: ORDER,
        payload: order //ascendente o descendente
    }
}

export function getCharacterByName(name) {
    return function(dispatch) {
        return fetch('https://rickandmortyapi.com/api/character/?name=' + name)
        .then((response) => response.json())
        .then((json) => {
            let characters = json.results
            dispatch({
                type: GET_CHARACTERS_BY_NAME,
                payload: characters
            })
        })
        .catch(e => console.log(e))
    }
}

export function getCharacters() {
    return function(dispatch) {
        //dispatch es el dispatch de mi store
        return fetch('https://rickandmortyapi.com/api/character')
        .then((response) => response.json())
        .then((json) => {
            let characters = json.results
            dispatch({
                type: GET_CHARACTERS,
                payload: characters
            })
        })
        .catch((e) => console.log(e))
    }
}

export function increment() {
    return {
        type: INCREMENTAR
    }
}

export function decrement() {
    return {
        type: DECREMENTAR
    }
}